import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertCircle, CheckCircle, AlertTriangle, X, Link, Plus } from 'lucide-react';
import { JoinBuilder } from './JoinBuilder';
import { MappingBuilder } from './MappingBuilder';
import { ColumnMapping, DataSource, Join, SelectedColumn, ValidationResult } from './types/mapping';

interface MappingAreaProps {
  applications: DataSource[];
  joins: Join[];
  mappings: ColumnMapping[];
  validationResults: ValidationResult;
  selectedColumns: SelectedColumn[];
  onJoinAdd: (join: Omit<Join, 'id'>) => void;
  onJoinUpdate: (joinId: string, updatedJoin: Join) => void;
  onJoinRemove: (joinId: string) => void;
  onMappingAdd: (mapping: Omit<ColumnMapping, 'id'>) => void;
  onMappingRemove: (mappingId: string) => void;
}

export const MappingArea: React.FC<MappingAreaProps> = ({
  applications,
  joins,
  mappings,
  validationResults,
  selectedColumns,
  onJoinAdd,
  onJoinUpdate,
  onJoinRemove,
  onMappingAdd,
  onMappingRemove
}) => {
  const [selectedMapping, setSelectedMapping] = useState<string | null>(null);
  const [showJoinBuilder, setShowJoinBuilder] = useState(false);
  const [showMappingBuilder, setShowMappingBuilder] = useState(false);

  const getValidationIcon = (status: 'passed' | 'failed' | 'warning') => {
    switch (status) {
      case 'passed':
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'failed':
        return <AlertCircle className="h-4 w-4 text-red-600" />;
      case 'warning':
        return <AlertTriangle className="h-4 w-4 text-yellow-600" />;
    }
  };

  const getValidationBadgeVariant = (status: 'passed' | 'failed' | 'warning') => {
    switch (status) {
      case 'passed':
        return 'default' as const;
      case 'failed':
        return 'destructive' as const;
      case 'warning':
        return 'secondary' as const;
    }
  };

  return (
    <Card className="h-full">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg">Mapping & Validation</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Tabs defaultValue="joins" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="joins">Joins</TabsTrigger>
            <TabsTrigger value="mappings">Column Mappings</TabsTrigger>
            <TabsTrigger value="validation">Validation</TabsTrigger>
          </TabsList>

          <TabsContent value="joins" className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-medium">Table Joins</h3>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setShowJoinBuilder(true)}
                className="h-7"
              >
                <Plus className="h-3 w-3 mr-1" />
                Add Join
              </Button>
            </div>

            <div className="space-y-3 max-h-[400px] overflow-y-auto">
              {joins.map((join) => (
                <div key={join.id} className="p-4 border rounded-lg space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-xs">
                        {join.sourceApplication}
                      </Badge>
                      <span className="text-sm font-medium">{join.sourceTable}</span>
                      <span className="text-xs text-muted-foreground">→</span>
                      <span className="text-sm font-medium">{join.targetTable}</span>
                      <Badge variant="outline" className="text-xs">
                        {join.targetApplication}
                      </Badge>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onJoinRemove(join.id)}
                      className="h-6 w-6 p-0"
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <span className="text-sm">{join.sourceTable}.{join.sourceColumn}</span>
                    <div className="h-px bg-border flex-1" />
                    <span className="text-sm">{join.targetTable}.{join.targetColumn}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <Select
                      value={join.joinType}
                      onValueChange={(value) => 
                        onJoinUpdate(join.id, { ...join, joinType: value as any })
                      }
                    >
                      <SelectTrigger className="w-32 h-7">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="INNER">INNER JOIN</SelectItem>
                        <SelectItem value="LEFT">LEFT JOIN</SelectItem>
                        <SelectItem value="RIGHT">RIGHT JOIN</SelectItem>
                        <SelectItem value="FULL">FULL JOIN</SelectItem>
                      </SelectContent>
                    </Select>
                    <span className="text-xs text-muted-foreground">(datatype compatible)</span>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="mappings" className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-medium">Column Mappings</h3>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setShowMappingBuilder(true)}
                className="h-7"
              >
                <Plus className="h-3 w-3 mr-1" />
                Add Mapping
              </Button>
            </div>

            <div className="space-y-3 max-h-[400px] overflow-y-auto">
              {mappings.map((mapping) => (
                <div 
                  key={mapping.id} 
                  className={`p-4 border rounded-lg space-y-3 cursor-pointer transition-colors ${
                    selectedMapping === mapping.id ? 'bg-muted/50' : ''
                  }`}
                  onClick={() => setSelectedMapping(mapping.id)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-xs">
                        {mapping.sourceApplication}
                      </Badge>
                      <span className="text-sm font-medium">{mapping.sourceTable}</span>
                      <span className="text-xs text-muted-foreground">→</span>
                      <span className="text-sm font-medium">{mapping.targetTable}</span>
                      <Badge variant="outline" className="text-xs">
                        {mapping.targetApplication}
                      </Badge>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        onMappingRemove(mapping.id);
                      }}
                      className="h-6 w-6 p-0"
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <span className="text-sm">{mapping.sourceTable}.{mapping.sourceColumn}</span>
                    <div className="h-px bg-border flex-1" />
                    <span className="text-sm">{mapping.targetTable}.{mapping.targetColumn}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    {getValidationIcon(mapping.validationStatus)}
                    <Badge variant={getValidationBadgeVariant(mapping.validationStatus)} className="h-5">
                      Validation
                    </Badge>
                    <span className="text-xs text-muted-foreground">
                      {mapping.validationMessage}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="validation" className="space-y-4">
            <div className="grid grid-cols-3 gap-4">
              <div className="p-4 border rounded-lg text-center">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  <span className="text-2xl font-bold text-green-600">
                    {validationResults.passed}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground">Passed</p>
              </div>
              <div className="p-4 border rounded-lg text-center">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <span className="text-2xl font-bold text-yellow-600">
                    {validationResults.warnings}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground">Warnings</p>
              </div>
              <div className="p-4 border rounded-lg text-center">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <AlertCircle className="h-5 w-5 text-red-600" />
                  <span className="text-2xl font-bold text-red-600">
                    {validationResults.failed}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground">Failed</p>
              </div>
            </div>

            <div className="p-4 border rounded-lg">
              <h4 className="font-medium mb-3">Selected Columns Summary</h4>
              <div className="space-y-2">
                {selectedColumns.map((item, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <Badge variant="outline">{item.application}</Badge>
                    <span className="text-sm">{item.table}</span>
                    <Badge variant="secondary" className="h-5">
                      {item.columns.length} columns
                    </Badge>
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>
        </Tabs>

        {/* Join Builder Dialog */}
        {showJoinBuilder && (
          <JoinBuilder
            applications={applications}
            onJoinAdd={onJoinAdd}
            onClose={() => setShowJoinBuilder(false)}
          />
        )}

        {/* Mapping Builder Dialog */}
        {showMappingBuilder && (
          <MappingBuilder
            applications={applications}
            onMappingAdd={onMappingAdd}
            onClose={() => setShowMappingBuilder(false)}
          />
        )}
      </CardContent>
    </Card>
  );
};
