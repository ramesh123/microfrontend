import { faker } from '@faker-js/faker';
import { Column, DataSource, Table } from '../types/mapping';

const createMockColumns = (count: number): Column[] => {
  const commonColumns = [
    { name: 'id', type: 'integer' },
    { name: 'created_at', type: 'timestamp' },
    { name: 'updated_at', type: 'timestamp' },
    { name: 'email', type: 'varchar(255)' },
    { name: 'name', type: 'varchar(100)' },
    { name: 'customer_id', type: 'integer' },
    { name: 'order_id', type: 'integer' },
    { name: 'amount', type: 'decimal' },
    { name: 'status', type: 'varchar(50)' },
    { name: 'txn_id', type: 'varchar(100)' },
    { name: 'value', type: 'decimal' },
    { name: 'user_id', type: 'integer' },
    { name: 'description', type: 'text' },
    { name: 'active', type: 'boolean' }
  ];

  return commonColumns.slice(0, count).map(col => ({
    ...col,
    selected: false
  }));
};

const createMockTables = (count: number): Table[] => {
  const tableNames = ['customers', 'orders', 'products', 'user_account', 'transaction', 'payments', 'inventory', 'categories'];
  
  return tableNames.slice(0, count).map(name => ({
    name,
    columns: createMockColumns(faker.number.int({ min: 3, max: 8 })),
    selected: false
  }));
};

export const mockDataSources: DataSource[] = [
  {
    id: '1',
    name: 'Nostro/Vostro/ Sett Entity ID',
    type: 'mysql',
    connected: true,
    tables: [
      {
        name: 'customers',
        columns: [
          { name: 'customer_id', type: 'integer', selected: true },
          { name: 'name', type: 'varchar(100)', selected: true },
          { name: 'email', type: 'varchar(255)', selected: true },
          { name: 'created_at', type: 'timestamp', selected: false },
          { name: 'active', type: 'boolean', selected: false },
        ],
        selected: true
      },
      {
        name: 'orders',
        columns: [
          { name: 'order_id', type: 'integer', selected: false },
          { name: 'customer_id', type: 'integer', selected: false },
          { name: 'amount', type: 'decimal', selected: false },
          { name: 'status', type: 'varchar(50)', selected: false },
          { name: 'created_at', type: 'timestamp', selected: false }
        ],
        selected: false
      }
    ]
  },
  {
    id: '2',
    name: 'Nostro/Vostro/ Sett Entity Cur',
    type: 'postgresql',
    connected: true,
    tables: [
      {
        name: 'user_account',
        columns: [
          { name: 'id', type: 'integer', selected: false },
          { name: 'email', type: 'varchar(255)', selected: false },
          { name: 'created_at', type: 'timestamp', selected: false }
        ],
        selected: false
      },
      {
        name: 'transaction',
        columns: [
          { name: 'txn_id', type: 'varchar(100)', selected: false },
          { name: 'value', type: 'decimal', selected: false },
          { name: 'status', type: 'varchar(50)', selected: false }
        ],
        selected: false
      }
    ]
  },
  {
    id: '3',
    name: 'Val/Settle Date',
    type: 'mysql',
    connected: true,
    tables: [
      {
        name: 'settlements',
        columns: [
          { name: 'settlement_id', type: 'integer', selected: false },
          { name: 'settlement_date', type: 'date', selected: false },
          { name: 'value_date', type: 'date', selected: false },
          { name: 'status', type: 'varchar(50)', selected: false }
        ],
        selected: false
      }
    ]
  },
  {
    id: '4',
    name: 'ExternalTxNum',
    type: 'postgresql',
    connected: false,
    tables: [
      {
        name: 'external_transactions',
        columns: [
          { name: 'external_tx_id', type: 'varchar(100)', selected: false },
          { name: 'transaction_number', type: 'varchar(50)', selected: false },
          { name: 'amount', type: 'decimal', selected: false }
        ],
        selected: false
      }
    ]
  },
  {
    id: '5',
    name: 'MAPS_TRDVERIFY-IMPORT',
    type: 'mysql',
    connected: true,
    tables: [
      {
        name: 'trade_verification',
        columns: [
          { name: 'trade_id', type: 'integer', selected: false },
          { name: 'verification_status', type: 'varchar(50)', selected: false },
          { name: 'import_date', type: 'timestamp', selected: false }
        ],
        selected: false
      }
    ]
  },
  {
    id: '6',
    name: 'Trade Remarks 1',
    type: 'postgresql',
    connected: true,
    tables: [
      {
        name: 'trade_remarks',
        columns: [
          { name: 'remark_id', type: 'integer', selected: false },
          { name: 'trade_id', type: 'integer', selected: false },
          { name: 'remark_text', type: 'text', selected: false }
        ],
        selected: false
      }
    ]
  },
  {
    id: '7',
    name: 'Cash Amt',
    type: 'mysql',
    connected: false,
    tables: [
      {
        name: 'cash_amounts',
        columns: [
          { name: 'cash_id', type: 'integer', selected: false },
          { name: 'amount', type: 'decimal', selected: false },
          { name: 'currency', type: 'varchar(3)', selected: false }
        ],
        selected: false
      }
    ]
  },
  {
    id: '8',
    name: 'Trans Num',
    type: 'postgresql',
    connected: true,
    tables: [
      {
        name: 'transactions',
        columns: [
          { name: 'transaction_id', type: 'integer', selected: false },
          { name: 'transaction_number', type: 'varchar(50)', selected: false },
          { name: 'transaction_date', type: 'timestamp', selected: false }
        ],
        selected: false
      }
    ]
  },
  {
    id: '9',
    name: 'FEED_FILE_NAME',
    type: 'mysql',
    connected: true,
    tables: [
      {
        name: 'feed_files',
        columns: [
          { name: 'file_id', type: 'integer', selected: false },
          { name: 'file_name', type: 'varchar(255)', selected: false },
          { name: 'file_path', type: 'varchar(500)', selected: false }
        ],
        selected: false
      }
    ]
  },
  {
    id: '10',
    name: 'Dr/Cr Ind',
    type: 'postgresql',
    connected: true,
    tables: [
      {
        name: 'debit_credit_indicators',
        columns: [
          { name: 'indicator_id', type: 'integer', selected: false },
          { name: 'indicator_type', type: 'varchar(10)', selected: false },
          { name: 'description', type: 'varchar(100)', selected: false }
        ],
        selected: false
      }
    ]
  }
];

export const mockValidationResults = {
  passed: 3,
  failed: 1,
  warnings: 2
};
