import React, { useState } from 'react';
import { MappingArea } from './MappingArea';
import { DataSourcePanel } from './DataSourcePanel';
import { ColumnMapping, DataSource, Join } from './types/mapping';
import { mockDataSources, mockValidationResults } from './data/mockData';

function RuleConfiguration() {
  const [dataSources, setDataSources] = useState<DataSource[]>(mockDataSources);
  const [joins, setJoins] = useState<Join[]>([
    {
      id: '1',
      sourceTable: 'customers',
      sourceColumn: 'customer_id',
      targetTable: 'user_account',
      targetColumn: 'id',
      joinType: 'INNER',
      sourceApplication: 'Production MySQL',
      targetApplication: 'Analytics PostgreSQL'
    }
  ]);
  
  const [mappings, setMappings] = useState<ColumnMapping[]>([
    {
      id: '1',
      sourceTable: 'customers',
      sourceColumn: 'email',
      targetTable: 'user_account',
      targetColumn: 'email',
      validationStatus: 'passed',
      validationMessage: 'datatype varchar = varchar',
      sourceApplication: 'Production MySQL',
      targetApplication: 'Analytics PostgreSQL'
    },
    {
      id: '2',
      sourceTable: 'customers',
      sourceColumn: 'customer_id',
      targetTable: 'user_account',
      targetColumn: 'id',
      validationStatus: 'warning',
      validationMessage: 'datatype integer ≠ bigint',
      sourceApplication: 'Production MySQL',
      targetApplication: 'Analytics PostgreSQL'
    }
  ]);

  const handleDataSourceUpdate = (sourceId: string, updatedSource: DataSource) => {
    setDataSources(prev => 
      prev.map(source => source.id === sourceId ? updatedSource : source)
    );
  };

  const handleAddSource = (newSource: Omit<DataSource, 'id'>) => {
    const sourceWithId: DataSource = {
      ...newSource,
      id: Date.now().toString()
    };
    setDataSources(prev => [...prev, sourceWithId]);
  };

  const handleAddJoin = (join: Omit<Join, 'id'>) => {
    const joinWithId: Join = {
      ...join,
      id: Date.now().toString()
    };
    setJoins(prev => [...prev, joinWithId]);
  };

  const handleJoinUpdate = (joinId: string, updatedJoin: Join) => {
    setJoins(prev => 
      prev.map(join => join.id === joinId ? updatedJoin : join)
    );
  };

  const handleJoinRemove = (joinId: string) => {
    setJoins(prev => prev.filter(join => join.id !== joinId));
  };

  const handleAddMapping = (mapping: Omit<ColumnMapping, 'id'>) => {
    const mappingWithId: ColumnMapping = {
      ...mapping,
      id: Date.now().toString()
    };
    setMappings(prev => [...prev, mappingWithId]);
  };

  const handleMappingRemove = (mappingId: string) => {
    setMappings(prev => prev.filter(mapping => mapping.id !== mappingId));
  };

  const getSelectedColumns = () => {
    const selectedColumns: { application: string; table: string; columns: string[] }[] = [];
    
    dataSources.forEach(source => {
      source.tables.forEach(table => {
        const columns = table.columns.filter(col => col.selected).map(col => col.name);
        if (columns.length > 0) {
          selectedColumns.push({
            application: source.name,
            table: table.name,
            columns
          });
        }
      });
    });
    
    return selectedColumns;
  };

  return (
    <div className="min-h-screen bg-background p-2">
      <div className="mx-auto max-w-[1400px]">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Applications Panel */}
          <div className="lg:col-span-1">
            <DataSourcePanel
              title="Applications"
              dataSources={dataSources}
              onDataSourceUpdate={handleDataSourceUpdate}
              onAddSource={handleAddSource}
            />
          </div>

          {/* Mapping & Validation Area */}
          <div className="lg:col-span-2">
            <MappingArea
              applications={dataSources}
              joins={joins}
              mappings={mappings}
              validationResults={mockValidationResults}
              selectedColumns={getSelectedColumns()}
              onJoinAdd={handleAddJoin}
              onJoinUpdate={handleJoinUpdate}
              onJoinRemove={handleJoinRemove}
              onMappingAdd={handleAddMapping}
              onMappingRemove={handleMappingRemove}
            />
          </div>
        </div>

      </div>
    </div>
  );
}

export default RuleConfiguration;
